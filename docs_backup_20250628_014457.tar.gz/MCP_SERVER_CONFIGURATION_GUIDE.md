# MCP Server Configuration Guide

## Overview
This guide documents the MCP (Model Context Protocol) server configurations for Claude Desktop.

## Configuration File Location
- **Windows**: `C:\Users\[username]\AppData\Roaming\Claude\claude_desktop_config.json`
- **macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`

## Current MCP Servers

### 1. GitHub MCP Server
```json
"github": {
  "command": "npx.cmd",
  "args": ["-y", "@modelcontextprotocol/server-github"],
  "env": {
    "GITHUB_PERSONAL_ACCESS_TOKEN": "your-github-token"
  }
}
```

### 2. Notion MCP Server (mcp-notion-server)
Third-party implementation with Markdown conversion support.

```json
"notion": {
  "command": "node",
  "args": ["C:\\Users\\spide\\Documents\\GitHub\\mcp-notion-server\\build\\index.js"],
  "env": {
    "NOTION_API_TOKEN": "your-notion-token",
    "NOTION_MARKDOWN_CONVERSION": "true"
  }
}
```

Alternative using npx:
```json
"notion": {
  "command": "npx.cmd",
  "args": ["-y", "@suekou/mcp-notion-server"],
  "env": {
    "NOTION_API_TOKEN": "your-notion-token",
    "NOTION_MARKDOWN_CONVERSION": "true"
  }
}
```

### 3. Official NotionHQ MCP Server (Optional)
```json
"notionApi": {
  "command": "npx.cmd",
  "args": ["-y", "@notionhq/notion-mcp-server"],
  "env": {
    "OPENAPI_MCP_HEADERS": "{\"Authorization\": \"Bearer your-notion-token\", \"Notion-Version\": \"2022-06-28\"}"
  }
}
```

### 4. Desktop Commander
```json
"desktop-commander": {
  "command": "npx.cmd",
  "args": ["-y", "@wonderwhy-er/desktop-commander"]
}
```

### 5. Playwright MCP Server
```json
"playwright": {
  "command": "npx.cmd",
  "args": [
    "@executeautomation/playwright-mcp-server",
    "--config",
    "C:\\Users\\spide\\Documents\\GitHub\\ALNTool\\storyforge\\frontend\\playwright-mcp-config.json"
  ],
  "cwd": "C:\\Users\\spide\\Documents\\GitHub\\ALNTool\\storyforge\\frontend"
}
```

## Troubleshooting

### Common Issues

1. **Module Not Found Error**
   - Ensure the path points to the built JavaScript file, not TypeScript source
   - For mcp-notion-server: Use `/build/index.js` not `/src/index.js`

2. **Server Disconnection**
   - Check the log files in `AppData\Roaming\Claude\logs\`
   - Verify all required environment variables are set
   - Ensure the server package is installed

3. **Permission Errors**
   - Ensure the Notion integration has required permissions
   - Verify the integration is connected to relevant pages/databases

### Log File Locations
- `AppData\Roaming\Claude\logs\mcp-server-[name].log`

### Verification Steps
1. After updating config, restart Claude Desktop
2. Check the MCP server status in Claude's interface
3. Review log files for any errors
4. Test basic commands to ensure connectivity

## Backup Strategy
Always create a backup before modifying the configuration:
```bash
cp claude_desktop_config.json claude_desktop_config.backup.$(date +%Y%m%d_%H%M%S).json
```