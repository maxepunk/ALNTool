# MCP (Model Context Protocol) User Guide

## Overview
MCP servers provide Claude Code with additional capabilities. They run automatically in the background when you start Claude Code - **no manual startup required**.

## Setup Status
✅ **All MCP servers are now properly configured with user scope**
- Notion, GitHub, and Desktop Commander: Available in all projects
- Playwright: Available in ALNTool project only

**Next Step**: Restart your Claude Code session to activate the servers.

## Currently Configured Servers

### 1. **Notion MCP** (User Scope - Available in All Projects)
**Purpose**: Direct access to your Notion workspace for reading and searching content.

**Available Commands**:
- Search Notion pages and databases
- Query specific databases
- Read page content in Markdown format

**Usage in Claude**:
```
# Example: Search for a page
Use the search_notion tool to find pages about "About Last Night"

# Example: Query a database
Use the query_database tool to get all characters from the ALN database
```

**Important Notes**:
- Configured with your API token (ends in ...PAf8G)
- Markdown conversion enabled for efficient token usage
- No manual server startup needed

### 2. **GitHub MCP** (User Scope - Available in All Projects)
**Purpose**: Interact with GitHub repositories, issues, and pull requests.

**Available Commands**:
- Search repositories
- Read file contents from repos
- Create/update issues
- Work with pull requests

**Usage in Claude**:
```
# Example: Search for issues
Use the GitHub search tool to find open issues in the ALNTool repository

# Example: Read a file from a repo
Use the GitHub tool to read the README from anthropics/claude-code repo
```

**Important Notes**:
- Configured with your personal access token (ends in ...40pm9)
- Can access both public and private repos you have access to
- No manual server startup needed

### 3. **Desktop Commander** (User Scope - Available in All Projects)
**Purpose**: Control desktop applications and simulate user interactions.

**Available Commands**:
- Open applications
- Simulate keyboard/mouse input
- Take screenshots
- Automate desktop workflows

**Usage in Claude**:
```
# Example: Open an application
Use the desktop commander to open Notepad

# Example: Take a screenshot
Use the desktop commander to capture the current screen
```

**Important Notes**:
- Works on Windows (through WSL)
- May require permissions for certain actions
- No manual server startup needed

### 4. **Playwright MCP** (Project Scope - ALNTool Only)
**Purpose**: Browser automation and testing for the ALNTool frontend.

**Configuration File**: `/mnt/c/Users/spide/Documents/GitHub/ALNTool/storyforge/frontend/playwright-mcp-config.json`

**Available Commands**:
- Navigate to URLs
- Click elements
- Fill forms
- Take screenshots
- Run automated tests
- Extract page content

**Usage in Claude**:
```
# Example: Navigate and screenshot
Use playwright to navigate to http://localhost:5173 and take a screenshot

# Example: Test a feature
Use playwright to click the "Sync Data" button and verify the response
```

**Important Notes**:
- Only available in the ALNTool project
- Config file specifies browser settings
- Great for testing UI changes
- No manual server startup needed

## How MCP Servers Work

1. **Automatic Startup**: When you run `claude` in a project, all configured MCP servers start automatically in the background.

2. **No Manual Management**: You don't need to:
   - Start servers manually
   - Keep terminal windows open
   - Manage server processes
   - Restart servers between sessions

3. **Scope Levels**:
   - **User Scope**: Available in all projects (notion, github, desktop-commander)
   - **Project Scope**: Only in specific project (playwright in ALNTool)

4. **Using MCP Tools**:
   - Simply ask Claude to use the tool
   - Claude will show available tools when relevant
   - You can ask "What MCP tools are available?" to see the list

## Troubleshooting

### If MCP servers aren't working:
1. Exit Claude Code: `Ctrl+C` or type `exit`
2. Restart Claude Code: `claude`
3. Check available tools with a test request

### To verify servers are configured:
```bash
claude mcp list
```

### To see detailed server info:
```bash
claude mcp get <server-name>
```

### Common Issues:
- **"No MCP servers configured"**: Servers might need reconfiguration
- **Tool not available**: Check if you're in the right project for project-scoped servers
- **API errors**: Verify tokens are still valid

## Best Practices

1. **Let Claude Know Your Intent**: Be specific about which tool you want to use
   - "Use Notion to search for..." 
   - "Use Playwright to test..."

2. **Provide Context**: Give Claude enough information
   - Database IDs for Notion queries
   - Full URLs for Playwright navigation
   - Repository names for GitHub operations

3. **Check Tool Availability**: Ask Claude what tools are available if unsure

4. **No Manual Server Management**: Remember, you never need to start/stop servers manually

## Quick Test Commands

To verify everything is working, try these:

1. **Test Notion**: "Use Notion MCP to search for 'About Last Night' pages"
2. **Test GitHub**: "Use GitHub MCP to list my recent repositories"
3. **Test Desktop Commander**: "Use Desktop Commander to take a screenshot"
4. **Test Playwright** (in ALNTool): "Use Playwright to navigate to http://localhost:5173"

## Configuration Locations

- **User-level MCPs**: Stored in Claude Code's internal config
- **Project-level MCPs**: `/mnt/c/Users/spide/Documents/GitHub/ALNTool/.mcp.json`
- **Playwright Config**: `/mnt/c/Users/spide/Documents/GitHub/ALNTool/storyforge/frontend/playwright-mcp-config.json`

Remember: All servers start automatically when you run `claude` - you just need to ask Claude to use them!